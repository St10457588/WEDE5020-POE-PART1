/**
 * Tapstone Plumbing Solutions - Main JavaScript
 * WEDE5020 Part 2: Interactive Features
 * Author: Nqobani Ngwenya (ST10457588)
 * Date: September 2026
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {

    // ============================================
    // 1. MOBILE MENU TOGGLE
    // ============================================

    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');

    if (mobileMenuToggle && mainNav) {
        mobileMenuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('active');

            // Toggle aria-expanded for accessibility
            const isExpanded = mainNav.classList.contains('active');
            mobileMenuToggle.setAttribute('aria-expanded', isExpanded);
        });
    }

    // ============================================
    // 2. DYNAMIC YEAR IN FOOTER
    // ============================================

    const yearElement = document.getElementById('current-year');
    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }

    // ============================================
    // 3. ENQUIRY FORM HANDLING
    // ============================================

    const enquiryForm = document.getElementById('enquiry-form');
    const enquiryFeedback = document.getElementById('form-feedback');

    if (enquiryForm) {
        enquiryForm.addEventListener('submit', function(event) {
            event.preventDefault();

            // Get form values
            const formData = new FormData(enquiryForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const phone = formData.get('phone');
            const service = formData.get('service');
            const location = formData.get('location');
            const message = formData.get('message');

            // Simple validation
            if (!name || !email || !phone || !service || !location || !message) {
                showFeedback(enquiryFeedback, 'Please fill in all required fields.', 'error');
                return;
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showFeedback(enquiryFeedback, 'Please enter a valid email address.', 'error');
                return;
            }

            // Simulate form submission (Part 3 will implement actual backend)
            // In production, this would send data to a server
            console.log('Form submitted:', {
                name, email, phone, service, location, message
            });

            // Show success message
            showFeedback(enquiryFeedback, 'Thank you! Your enquiry has been submitted. We will contact you within 24 hours.', 'success');

            // Reset form
            enquiryForm.reset();

            // Hide feedback after 5 seconds
            setTimeout(() => {
                enquiryFeedback.className = 'form-feedback';
                enquiryFeedback.textContent = '';
            }, 5000);
        });
    }

    // ============================================
    // 4. CONTACT FORM HANDLING
    // ============================================

    const contactForm = document.getElementById('contact-form');
    const contactFeedback = document.getElementById('contact-feedback');

    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const formData = new FormData(contactForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const message = formData.get('message');

            if (!name || !email || !message) {
                showFeedback(contactFeedback, 'Please fill in all required fields.', 'error');
                return;
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showFeedback(contactFeedback, 'Please enter a valid email address.', 'error');
                return;
            }

            console.log('Contact form submitted:', { name, email, message });

            showFeedback(contactFeedback, 'Thank you! Your message has been sent. We will respond within 24 hours.', 'success');
            contactForm.reset();

            setTimeout(() => {
                contactFeedback.className = 'form-feedback';
                contactFeedback.textContent = '';
            }, 5000);
        });
    }

    // ============================================
    // 5. FEEDBACK DISPLAY HELPER
    // ============================================

    function showFeedback(element, message, type) {
        if (!element) return;

        element.textContent = message;
        element.className = `form-feedback ${type}`;
        element.style.display = 'block';

        // Scroll to feedback if off-screen
        element.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    // ============================================
    // 6. SMOOTH SCROLL FOR ANCHOR LINKS
    // ============================================

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');

            // Only handle internal anchors (not #)
            if (href.length > 1) {
                const target = document.querySelector(href);

                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });

    // ============================================
    // 7. ACTIVE NAV LINK BASED ON CURRENT PAGE
    // ============================================

    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link');

    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href');

        if (linkHref === currentPage) {
            link.classList.add('active');
            link.setAttribute('aria-current', 'page');
        } else {
            link.classList.remove('active');
            link.removeAttribute('aria-current');
        }
    });

    // ============================================
    // 8. FORM INPUT VALIDATION ON BLUR
    // ============================================

    const requiredInputs = document.querySelectorAll('input[required], textarea[required], select[required]');

    requiredInputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (!this.value.trim()) {
                this.style.borderColor = 'var(--color-error)';
            } else {
                this.style.borderColor = 'transparent';

                // Additional email validation
                if (this.type === 'email') {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(this.value)) {
                        this.style.borderColor = 'var(--color-error)';
                    }
                }
            }
        });

        // Clear error on input
        input.addEventListener('input', function() {
            this.style.borderColor = 'var(--color-primary)';
        });
    });

    // ============================================
    // 9. SERVICE CARD ANIMATION ON SCROLL
    // ============================================

    const serviceCards = document.querySelectorAll('.service-card, .value-card, .team-member');

    if (serviceCards.length > 0 && 'IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });

        serviceCards.forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });
    }

    // ============================================
    // 10. CONSOLE WELCOME MESSAGE
    // ============================================

    console.log('%c Tapstone Plumbing Solutions ', 'background: #1E3A8A; color: #fff; font-size: 16px; padding: 10px;');
    console.log('Website built for WEDE5020 - Part 2');
    console.log('Developer: Nqobani Ngwenya (ST10457588)');
    console.log('For enquiries, visit the Enquiry page or call 011 123 4567');

});
