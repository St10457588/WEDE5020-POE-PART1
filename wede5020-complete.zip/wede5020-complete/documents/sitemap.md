# WEDE5020 Website Sitemap
## Tapstone Plumbing Solutions

**Student:** Nqobani Ngwenya  
**Student Number:** ST10457588  
**Date:** September 2026

---

## Visual Sitemap

```
┌─────────────────────────────────────────────────────────┐
│                    HOMEPAGE (index.html)                │
│  • Hero section with CTA buttons                        │
│  • Services overview (4 cards)                          │
│  • Trust indicators (4 reasons to choose us)            │
│  • Call-to-action section                               │
└─────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌───────────────┐  ┌─────────────────┐  ┌───────────────┐
│  ABOUT US     │  │    SERVICES     │  │   ENQUIRY     │
│ (about.html)  │  │ (services.html) │  │(enquiry.html) │
│               │  │                 │  │               │
│ • Our Story   │  │ • Emergency     │  │ • Contact form│
│ • Mission     │  │ • Geyser        │  │ • Service     │
│ • Vision      │  │ • Renovations   │  │   selection   │
│ • Values (4)  │  │ • Compliance    │  │ • Location    │
│ • Team (4)    │  │                 │  │ • Validation  │
│ • Certs (2)   │  │                 │  │               │
└───────────────┘  └─────────────────┘  └───────────────┘
                            │
                            ▼
                  ┌─────────────────┐
                  │    CONTACT      │
                  │ (contact.html)  │
                  │                 │
                  │ • Contact info  │
                  │ • Contact form  │
                  │ • Randburg map  │
                  │ • Benoni map    │
                  └─────────────────┘
```

---

## Page Hierarchy

### Level 1: Homepage
- **File:** `index.html`
- **Purpose:** Main landing page, service overview, trust building
- **Key Elements:** Hero, services grid, trust section, CTA

### Level 2: Interior Pages

#### About Us
- **File:** `about.html`
- **Purpose:** Company background, team introduction, credentials
- **Key Elements:** Story, mission/vision, values, team profiles, certifications

#### Services
- **File:** `services.html`
- **Purpose:** Detailed service descriptions
- **Key Elements:** 4 service sections with details, pricing guidance, CTAs

#### Enquiry
- **File:** `enquiry.html`
- **Purpose:** Lead capture through quote requests
- **Key Elements:** Form with service dropdown, location selection, validation

#### Contact
- **File:** `contact.html`
- **Purpose:** Contact information and location details
- **Key Elements:** Contact details, form, two location maps

---

## Navigation Structure

### Primary Navigation (Header)
1. Home
2. About Us
3. Services
4. Enquiry
5. Contact

### Footer Navigation
- Quick Links (all 5 pages)
- Services (4 service links with anchors)
- Contact Information

### Breadcrumb Navigation
- Appears on all interior pages
- Format: Home / Current Page

---

## File Organisation

```
Root Folder/
│
├── index.html
├── about.html
├── services.html
├── enquiry.html
├── contact.html
│
├── css/
│   └── styles.css
│
├── js/
│   └── main.js
│
├── images/
│   ├── hero-bg.jpg (placeholder)
│   ├── team/ (4 photos)
│   └── services/ (4 photos)
│
├── documents/
│   └── proposals.md
│
└── content/
    └── page-texts.txt
```

---

## URL Structure

All pages use clean, descriptive filenames:

- `/index.html` (or `/` on live server)
- `/about.html`
- `/services.html`
- `/enquiry.html`
- `/contact.html`

### Anchor Links (within Services page)

- `/services.html#emergency`
- `/services.html#geysers`
- `/services.html#renovations`
- `/services.html#compliance`

---

## Content Strategy

### Homepage
- Above fold: Hero with clear value proposition
- Middle: Service highlights with icons
- Bottom: Trust signals and primary CTA

### About Page
- Top: Company story and founding
- Middle: Mission, vision, values
- Bottom: Team introductions and certifications

### Services Page
- Sequential sections for each service
- Alternating image/text layouts
- Clear CTAs after each section

### Enquiry Page
- Left: Form with validation
- Right: Why choose us, emergency contact

### Contact Page
- Left: Contact details and hours
- Right: Contact form
- Bottom: Two location cards with maps

---

**Document Version:** 1.0  
**Last Updated:** 18 September 2026
